var mysql = require('mysql');
const express = require('express')
var url = require('url');
var nodemailer = require('nodemailer');
const app = express()

app.use(express.static('public'));

const port = 8000

/*var db_config = {
  host: "remotemysql.com",
  port: "3306",
  user: "0taR7i38cx",
  password: "39FchDTVVy",
  database: "0taR7i38cx",
  insecureAuth : true
};*/
var db_config = {
  host: "localhost",
  user: "root",
  password: "$Badcs340"
};

var con;

function handleDisconnect() {
  con = mysql.createConnection(db_config); 
  con.connect(function(err) {           
    if(err) {                                    
      console.log('error when connecting to db:', err);
      setTimeout(handleDisconnect, 2000); // We introduce a delay before attempting to reconnect,
    }
    console.log("Connected to local database at localhost on port 3306!");                  
  });                                     
  con.on('error', function(err) {
    console.log('db error', err);
    if(err.code === 'PROTOCOL_CONNECTION_LOST') { // Connection to the MySQL server is usually
      handleDisconnect();                         // lost due to either server restart, or a
    } else {                                      // connnection idle timeout (the wait_timeout
      throw err;                                  // server variable configures this)
    }
  });
}

handleDisconnect();

var generate_tables = `create table user (
id INT AUTO_INCREMENT,
first_name varchar(50) not null,
last_name varchar(50) not null,
email varchar(320) not null,
password varchar(100) not null,
gender varchar(50) not null,
primary key(id)
)`;

 con.query("use user", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });

 /*con.query(generate_tables, function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });*/

//write your server code below

app.post('/register/', (req, res) => {
  var q = url.parse(req.url, true);
  q = q.query;
  res.setHeader("Access-Control-Allow-Origin", "*");

  var select_st = `select * from user where email='${q.email}'`;
  con.query(select_st, function (err, result1, fields1) {
    if (err) throw err;
    
    if(result1.length == 0){
      
      var insert_st = `insert into user (first_name,last_name,email,password,gender)
      values ('${q.first}','${q.last}','${q.email}','${q.password}','${q.gender}')`;
  
      con.query(insert_st, function (err, result, fields) {
        if (err) throw err;
      });
      console.log('ID registered');
      res.send("Account created!");

    }
    else{
      res.send("Account could not be created. The email id allready exits!");
    }
  })
});

app.get('/login/', (req, res) => {
  var q = url.parse(req.url, true);
  res.setHeader("Access-Control-Allow-Origin", "*");
  q = q.query;
  var select_st = `select * from user where email='${q.email}' and password='${q.password}'`
  con.query(select_st, function (err, result, fields) {
    if (err) throw err;
    if(result.length == 0){
      res.send("NULL");
    }
    else{
      res.send(JSON.stringify(result));
    }
    console.log('login => ',result);
  });
});

app.get('/change_profile/',(req, res) => {
  var q = url.parse(req.url, true);
  res.setHeader("Access-Control-Allow-Origin", "*");
  q = q.query;
  var update_st = `update user 
                   set first_name='${q.first}',last_name='${q.last}'
                   where id ='${q.id}'`

  con.query(update_st, function (err, result, fields) {
    if (err) throw err;
    res.send("Account updated!");
  });
  console.log("account updated =>", q)
});

app.get('/change_password/',(req, res) => {
  var q = url.parse(req.url, true);
  res.setHeader("Access-Control-Allow-Origin", "*");
  q = q.query;
  var update_st = `update user 
                   set password='${q.password}'
                   where id ='${q.id}'`

  con.query(update_st, function (err, result, fields) {
    if (err) throw err;
    res.send("Password updated!");
  });
  console.log("password changed =>", q);
});

app.get('/delete_user/',(req, res) => {
  var q = url.parse(req.url, true);
  res.setHeader("Access-Control-Allow-Origin", "*");
  q = q.query;
  var del_st = `delete from user where id ='${q.id}'`

  con.query(del_st, function (err, result, fields) {
    if (err) throw err;
    res.send("account deleted!");
  });
  console.log("account deleted =>",q);
});




app.listen(port, () => {
  console.log(`App listening at http://localhost:${port}`)
});
